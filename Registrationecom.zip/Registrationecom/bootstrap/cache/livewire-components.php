<?php return array (
  'admin.admin-add-employee-component' => 'App\\Http\\Livewire\\Admin\\AdminAddEmployeeComponent',
  'admin.admin-edit-employee-component' => 'App\\Http\\Livewire\\Admin\\AdminEditEmployeeComponent',
  'admin.admin-employee-component' => 'App\\Http\\Livewire\\Admin\\AdminEmployeeComponent',
  'admin.admin-settings-component' => 'App\\Http\\Livewire\\Admin\\AdminSettingsComponent',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'user.user-dashboard-component' => 'App\\Http\\Livewire\\User\\UserDashboardComponent',
);