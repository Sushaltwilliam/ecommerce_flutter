<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            // $table->integer('employeeid')->nullable();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('phone');
            $table->string('emergencydetails');
            $table->string('designation');
            $table->string('category');
            $table->string('department');
            $table->string('address');
            $table->string('profile')->nullable();
            $table->timestamps();
        });
     

       
    
       DB::update("ALTER TABLE employees AUTO_INCREMENT = 1000; ");
        
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}
