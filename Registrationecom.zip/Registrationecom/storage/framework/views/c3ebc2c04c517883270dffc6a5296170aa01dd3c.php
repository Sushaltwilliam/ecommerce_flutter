<div>
    User
</div>
<?php /**PATH C:\xampp\htdocs\Registrationecom\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>