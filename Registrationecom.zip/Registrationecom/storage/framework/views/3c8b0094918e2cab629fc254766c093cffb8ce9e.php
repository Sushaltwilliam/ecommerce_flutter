<div>
    <div class="container" style="padding:30px 0;">
        <div class="row">
             <div class="col-md-12">
                 <div class="panel panel-default">
                     <div class="panel-heading">
                         <div class="row">
                             <div class="col-md-6">
                                 Add New Employee
                             </div>
                             <div class="col-md-6">
                                 <a href="<?php echo e(route('admin.employee')); ?>" class="btn btn-success pull-right">All Employee</a>
                             </div>
                         </div>
                     </div>
                     <div class="panel-body">
                         <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                         <?php endif; ?>
                         <form class="form-horizontal" enctype="multipart/form-data" wire:submit.prevent="addEmployee" >

                           

                             <div class="form-group">
                                 <label class="col-md-4 control-label">Employee Name</label>
                                 <div class="col-md-4">
                                     <input type="text" placeholder="Employee Name" class="form-control input-md" wire:model="name" />
                                     <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                             </div>


                            <div class="form-group">
                                <label class="col-md-4 control-label">Email</label>
                                <div class="col-md-4">
                                    <input type="email" placeholder="example@example.com" class="form-control input-md" wire:model="email"/> 
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                  
                                    
                                                                        
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-md-4 control-label">Phone</label>
                                <div class="col-md-4">
                                    <input type="number" placeholder="" class="form-control input-md" wire:model="phone" />
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>    
                            
                            <div class="form-group">
                                <label class="col-md-4 control-label">Emergency Details</label>
                                <div class="col-md-4">
                                    <input type="number" placeholder="Alternative mobile no" class="form-control input-md" wire:model="emergencydetails" />
                                    
                                    <?php if($errors->has('emergencydetails')): ?>
                                        <div class="error" style="color:rgb(126, 20, 20);"><?php echo e($errors->first('emergencydetails')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>    



                           
                             
                             <div class="form-group">
                                 <label class="col-md-4 control-label">Designation</label>
                                 <div class="col-md-4">
                                    <input type="text" placeholder="" class="form-control input-md" wire:model="designation" />
                                     <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                             </div>

                             <div class="form-group">
                                <label class="col-md-4 control-label">Category</label>
                                <div class="col-md-4">
                                    <select class="form-control form-select" wire:model="category" aria-label="Default select example">
                                        <option value="" >SelectCategory</option>
                                        <option value="high">High</option>
                                        <option value="medium">Medium</option>
                                        <option value="low">Low</option>
                                    </select>
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                           

                            <div class="form-group">
                                <label class="col-md-4 control-label">Department</label>
                                <div class="col-md-4">
                                    <select class="form-control" wire:model="department" >
                                        <option value="">SelectDepartment</option>
                                        <option value="Marketing">Marketing</option>
                                        <option value="HR">HR</option>
                                        <option value="Web">Web</option>
                                    </select>
                                    <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                              
                            <div class="form-group">
                                <label class="col-md-4 control-label">Address</label>
                                <div class="col-md-4">
                                    
                                    <textarea name="address"  id="" class="form-control"  cols="30" rows="5" wire:model="address"></textarea>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            


                            <div class="form-group">
                                <label class="col-md-4 control-label">Profile</label>
                                <div class="col-md-4">
                                    <input type="file" placeholder="" class="input-file" wire:model="profile"/>
                                    <?php if($profile): ?>
                                    <img src="<?php echo e($profile->temporaryUrl()); ?>" width="120" />  
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>    
                            
                            
                             <div class="form-group">
                                <label class="col-md-4 control-label"></label>
                                <div class="col-md-4">
                                     <button type="submit" class="btn btn-primary" >Submit</button>
                                </div>
                            </div>

                         </form>
                     </div>
                 </div>
             </div>
        </div>
    </div>
 </div>
 
 
<?php /**PATH C:\xampp\htdocs\Registrationecom\resources\views/livewire/admin/admin-add-employee-component.blade.php ENDPATH**/ ?>