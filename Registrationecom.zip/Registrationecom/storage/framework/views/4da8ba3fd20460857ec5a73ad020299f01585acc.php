



    <div>
		<h1>Welcome Admin</h1>
	</div><?php /**PATH C:\xampp\htdocs\Registrationecom\resources\views/livewire/home-component.blade.php ENDPATH**/ ?>