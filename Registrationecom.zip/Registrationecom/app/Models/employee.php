<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class employee extends Model
{   
    protected $table="employees";
    // protected $fillable = ['employeeid','name','email','phone','emergencydetails','designation','category','department','address','profile' ];
    use HasFactory;
}