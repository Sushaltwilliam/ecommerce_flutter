<?php

namespace App\Http\Livewire\Admin;


use Carbon\Carbon;
use Livewire\Component;
use App\Models\employee;
use Livewire\WithFileUploads;
use Illuminate\Validation\Rule;


class AdminEditEmployeeComponent extends Component
{

    use WithFileUploads;
    
    public $name;
    public $email;
    public $phone;
    public $emergencydetails;
    public $designation;
    public $category;
    public $department;
    public $address;
    public $profile;
    public $newprofile;
    public $employee_id;
    public $employee;


    public function updated($fields)
    {
        $this->validateOnly($fields,[
                    'name'=> 'required',
                    // 'email' => 'required|unique:employees|max:255',
                    'email' => Rule::unique('employees')->ignore($this->employee_id),    
                    'phone' => 'required|digits:10',
                    'emergencydetails' => 'required|digits:10',
                    'designation' => 'required',
                    'category' => 'required',
                    'department' => 'required',
                    'address' => 'required',
                    'profile'=> 'required'
            
        ]);


        

        if($this->newprofile)
        {
            $this->validateOnly($fields,[
                'newprofile'=> 'required|mimes:jpeg,png',
            ]);
        }
    }

    
 
    public function mount($employee_id)
    {

        $employee=employee::where('id',$employee_id)->first();
        $this->name=$employee->name;
        $this->email=$employee->email;
        $this->phone=$employee->phone;
        $this->emergencydetails=$employee->emergencydetails;
        $this->designation=$employee->designation;
        $this->category=$employee->category;
        $this->department=$employee->department;
        $this->address=$employee->address;
        $this->profile=$employee->profile;
        $this->employee_id=$employee->id;
    }

    public function updateEmployee()
    {

       
        $this->validate([
            'name' => 'required',
            // 'email' => 'required|unique:employees|max:255',
            'email' => Rule::unique('employees')->ignore($this->employee_id),
            'phone' => 'required|digits:10',
            'emergencydetails' => 'required|digits:10',
            'designation' => 'required',
            'category' => 'required',
            'department' => 'required',
            'address' => 'required',
            'profile'=> 'required'
            
    ]);

   
      


        if($this->newprofile)
        {
            $this->validate([
                'newprofile'=> 'required|mimes:jpeg,png',
            ]);
        }


      

         $employee=employee::find($this->employee_id);
         $employee->name=$this->name;
         $employee->email=$this->email;
         $employee->phone=$this->phone;
         $employee->emergencydetails=$this->emergencydetails;
         $employee->designation=$this->designation;
         $employee->category=$this->category;
         $employee->department=$this->department;
         $employee->address=$this->address;
        //  $employee->profile=$this->profile;
         if($this->newprofile)
         {
             unlink('assets/images/profiles'.'/'.$employee->profile);
             $profileName=Carbon::now()->timestamp.'.'.$this->newprofile->extension();
             $this->newprofile->storeAs('profiles',$profileName);
             $employee->profile=$profileName;
         }
         

        $employee->save();
         session()->flash('message','Employee has been updated successfully!');

    }
    public function render()
    {
        return view('livewire.admin.admin-edit-employee-component')->layout('layouts.base');
    }
}

