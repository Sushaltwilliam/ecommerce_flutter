<?php

namespace App\Http\Livewire\Admin;

use Carbon\Carbon;
use Livewire\Component;
use App\Models\employee;
use Livewire\WithFileUploads;


class AdminAddEmployeeComponent extends Component
{
    use WithFileUploads;
    
    public $name;
    public $email;
    public $phone;
    public $emergencydetails;
    public $designation;
    public $category;
    public $department;
    public $address;
    public $profile;
    public $emp;

    

    public function updated($fields)
    {
        $this->validateOnly($fields,[
                    'name'=> 'required',
                    'email' => 'required|unique:employees|max:255',
                    'phone' => 'required|digits:10',
                    'emergencydetails'=> 'required|digits:10',
                    'designation' => 'required',
                    'category' => 'required',
                    'department' => 'required',
                    'address' => 'required',
                    'profile'=> 'required'
            
        ]);
    }

    public function addEmployee()
    {
        

        $this->validate([
                    'name' => 'required',
                    'email' => 'required|unique:employees|max:255',
                    'phone' => 'required|digits:10',
                    'emergencydetails' => 'required|digits:10',
                    'designation' => 'required',
                    'category' => 'required',
                    'department' => 'required',
                    'address' => 'required',
                    'profile'=> 'required'
                    
        ]);

        $employee=new employee();
        $employee->name=$this->name;
        $employee->email=$this->email;
        $employee->phone=$this->phone;
        $employee->emergencydetails=$this->emergencydetails;
        $employee->designation=$this->designation;
        $employee->category=$this->category;
        $employee->department=$this->department;
        $employee->address=$this->address;
       
        $profileName=Carbon::now()->timestamp.'.'.$this->profile->extension();
        $this->profile->storeAs('profiles',$profileName);
        $employee->profile=$profileName;

        $employee->save();
        session()->flash('message','Employee has been added successfully!');


      

    }
   

    public function render()
    {
     return view('livewire.admin.admin-add-employee-component')->layout('layouts.base');
    }
}
