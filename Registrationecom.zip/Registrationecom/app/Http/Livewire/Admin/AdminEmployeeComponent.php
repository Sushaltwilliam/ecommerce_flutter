<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;
use App\Models\employee;
use Livewire\WithPagination;


class AdminEmployeeComponent extends Component
{
    use WithPagination;

    public function deleteEmployee($id)
    {
        $employee =employee::find($id);
        $employee->delete();
        session()->flash('message','employee has been deleted successfully!');

    }
    public function render()
    {
        $employees = employee::paginate(10);
        return view('livewire.admin.admin-employee-component',['employees'=>$employees])->layout('layouts.base');
    }
}

