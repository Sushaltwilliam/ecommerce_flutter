<div>
    <div class="container" style="padding:30px 0;">
        <div class="row">
             <div class="col-md-12">
                 <div class="panel panel-default">
                     <div class="panel-heading">
                         <div class="row">
                             <div class="col-md-6">
                                 Add New Employee
                             </div>
                             <div class="col-md-6">
                                 <a href="{{ route('admin.employee') }}" class="btn btn-success pull-right">All Employee</a>
                             </div>
                         </div>
                     </div>
                     <div class="panel-body">
                         @if (Session::has('message'))
                            <div class="alert alert-success" role="alert">{{ Session::get('message') }}</div>
                         @endif
                         <form class="form-horizontal" enctype="multipart/form-data" wire:submit.prevent="addEmployee" >

                           

                             <div class="form-group">
                                 <label class="col-md-4 control-label">Employee Name</label>
                                 <div class="col-md-4">
                                     <input type="text" placeholder="Employee Name" class="form-control input-md" wire:model="name" />
                                     @error('name') <p class="text-danger">{{ $message }}</p>
                                     @enderror
                                 </div>
                             </div>


                            <div class="form-group">
                                <label class="col-md-4 control-label">Email</label>
                                <div class="col-md-4">
                                    <input type="email" placeholder="example@example.com" class="form-control input-md" wire:model="email"/> 
                                    @error('email') <p class="text-danger">{{ $message }}</p>@enderror
                                    
                                  
                                    {{-- @if (Session::has('msg'))
                                        <div class="alert alert-success" role="alert">{{ Session::get('msg') }}</div>
                                    @endif  --}}
                                                                        
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-md-4 control-label">Phone</label>
                                <div class="col-md-4">
                                    <input type="number" placeholder="" class="form-control input-md" wire:model="phone" />
                                    @error('phone') <p class="text-danger">{{ $message }}</p>@enderror
                                </div>
                            </div>    
                            
                            <div class="form-group">
                                <label class="col-md-4 control-label">Emergency Details</label>
                                <div class="col-md-4">
                                    <input type="number" placeholder="Alternative mobile no" class="form-control input-md" wire:model="emergencydetails" />
                                    {{-- @error('phone') <p class="text-danger">{{ $message }}</p>@enderror --}}
                                    @if($errors->has('emergencydetails'))
                                        <div class="error" style="color:rgb(126, 20, 20);">{{ $errors->first('emergencydetails') }}</div>
                                    @endif
                                </div>
                            </div>    



                           
                             
                             <div class="form-group">
                                 <label class="col-md-4 control-label">Designation</label>
                                 <div class="col-md-4">
                                    <input type="text" placeholder="" class="form-control input-md" wire:model="designation" />
                                     @error('designation') <p class="text-danger">{{ $message }}</p>@enderror
                                 </div>
                             </div>

                             <div class="form-group">
                                <label class="col-md-4 control-label">Category</label>
                                <div class="col-md-4">
                                    <select class="form-control form-select" wire:model="category" aria-label="Default select example">
                                        <option value="" >SelectCategory</option>
                                        <option value="high">High</option>
                                        <option value="medium">Medium</option>
                                        <option value="low">Low</option>
                                    </select>
                                    @error('category') <p class="text-danger">{{ $message }}</p>@enderror
                                </div>
                            </div>

                           

                            <div class="form-group">
                                <label class="col-md-4 control-label">Department</label>
                                <div class="col-md-4">
                                    <select class="form-control" wire:model="department" >
                                        <option value="">SelectDepartment</option>
                                        <option value="Marketing">Marketing</option>
                                        <option value="HR">HR</option>
                                        <option value="Web">Web</option>
                                    </select>
                                    @error('department') <p class="text-danger">{{ $message }}</p>@enderror
                                </div>
                            </div>
                              
                            <div class="form-group">
                                <label class="col-md-4 control-label">Address</label>
                                <div class="col-md-4">
                                    
                                    <textarea name="address"  id="" class="form-control"  cols="30" rows="5" wire:model="address"></textarea>
                                    @error('address') <p class="text-danger">{{ $message }}</p>
                                    @enderror
                                </div>
                            </div>


                            


                            <div class="form-group">
                                <label class="col-md-4 control-label">Profile</label>
                                <div class="col-md-4">
                                    <input type="file" placeholder="" class="input-file" wire:model="profile"/>
                                    @if($profile)
                                    <img src="{{ $profile->temporaryUrl() }}" width="120" />  
                                    @endif
                                    @error('profile') <p class="text-danger">{{ $message }}</p>@enderror
                                </div>
                            </div>    
                            
                            {{-- <div class="form-group">
                                 <label class="col-md-4 control-label"></label>
                                 <div class="col-md-4">
                                    @if (Session::has('msg'))
                                       <button type="submit" class="btn btn-primary" disabled>Submit</button>  
                                    @else
                                      <button type="submit" class="btn btn-primary" >Submit</button>
                                    @endif 
                                 </div>
                             </div> --}}
                             <div class="form-group">
                                <label class="col-md-4 control-label"></label>
                                <div class="col-md-4">
                                     <button type="submit" class="btn btn-primary" >Submit</button>
                                </div>
                            </div>

                         </form>
                     </div>
                 </div>
             </div>
        </div>
    </div>
 </div>
 
 
