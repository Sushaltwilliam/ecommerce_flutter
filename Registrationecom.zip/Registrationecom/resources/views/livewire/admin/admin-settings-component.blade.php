<div>
    <div class="container" style="padding:30px 0">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Settings
                    </div>
                    <div class="panel-body">
                        <a title="Empoyee Details" href="{{ route('admin.employee') }}">Employee Details</a>
                        {{-- <a title="Empoyee Details" href="">Employee Details</a> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


